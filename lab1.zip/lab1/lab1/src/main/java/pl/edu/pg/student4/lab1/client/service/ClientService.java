package pl.edu.pg.student4.lab1.client.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pl.edu.pg.student4.lab1.client.entity.Clients;
import pl.edu.pg.student4.lab1.client.repository.ClientRepository;
import pl.edu.pg.student4.lab1.credit.entity.Credits;

import java.util.List;
import java.util.Optional;

@Service
public class ClientService {

    private ClientRepository repository;



    @Autowired
    public ClientService(ClientRepository repository) {
        this.repository = repository;
    }

    public Optional<Clients> find(Long id) {
        return repository.find(id);
    }

    public List<Credits> findAll() {
        return null;
    }

    public void create(Clients Clients) {
        repository.create(Clients);
    }

    public void update(Clients Clients) {
        repository.update(Clients);
    }

    public void delete(Long Clients) {
        repository.delete(repository.find(Clients).orElseThrow());
    }
}