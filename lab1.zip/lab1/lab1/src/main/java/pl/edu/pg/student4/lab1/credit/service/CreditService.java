package pl.edu.pg.student4.lab1.credit.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pl.edu.pg.student4.lab1.credit.entity.Credits;
import pl.edu.pg.student4.lab1.credit.repository.CreditRepository;

import java.util.List;
import java.util.Optional;

@Service
public class CreditService {

    private CreditRepository repository;


    @Autowired
    public CreditService(CreditRepository repository) {
        this.repository = repository;
    }

    public Optional<Credits> find(Long id) {
        return repository.find(id);
    }

    public List<Credits> findAll() {
        return null;
    }

    public void create(Credits Credits) {
        repository.create(Credits);
    }

    public void update(Credits Credits) {
        repository.update(Credits);
    }

    public void delete(Long Credits) {
        repository.delete(repository.find(Credits).orElseThrow());
    }
}