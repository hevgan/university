package pl.edu.pg.student4.lab1.client.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;



@Getter
@Setter
@NoArgsConstructor
@ToString
public class Clients {
    private String name;
    private String surname;
    private Integer age;
}
