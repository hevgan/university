package pl.edu.pg.student4.lab1.client.repository;

import pl.edu.pg.student4.lab1.client.entity.Clients;
import pl.edu.pg.student4.lab1.repository.Repository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@org.springframework.stereotype.Repository
public class ClientRepository implements Repository<Clients, Long> {
    @Override
    public Optional<Clients> find(Long id) {
        return Optional.empty();
    }

    @Override
    public List<Clients> findAll() {
        return null;
    }

    @Override
    public void create(Clients entity) {

    }

    @Override
    public void delete(Clients entity) {

    }

    @Override
    public void update(Clients entity) {

    }
}
