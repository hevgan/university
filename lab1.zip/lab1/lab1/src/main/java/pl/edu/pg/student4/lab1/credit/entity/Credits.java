package pl.edu.pg.student4.lab1.credit.entity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;



@Getter
@Setter
@NoArgsConstructor
@ToString
public class Credits {
    private Integer amount;
}
