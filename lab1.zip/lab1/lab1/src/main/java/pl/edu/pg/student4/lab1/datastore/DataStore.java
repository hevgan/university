package pl.edu.pg.student4.lab1.datastore;

import org.springframework.stereotype.Component;
import pl.edu.pg.student4.lab1.client.entity.Clients;
import pl.edu.pg.student4.lab1.credit.entity.Credits;

import java.util.HashSet;
import java.util.Set;

@Component
public class DataStore {

    private Set<Credits> credits = new HashSet<>();

    private Set<Clients> clients = new HashSet<>();

}
