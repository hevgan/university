package pl.edu.pg.student4.lab1.credit.repository;

import pl.edu.pg.student4.lab1.credit.entity.Credits;
import pl.edu.pg.student4.lab1.repository.Repository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@org.springframework.stereotype.Repository
public class CreditRepository implements Repository<Credits, Long> {
    @Override
    public Optional<Credits> find(Long id) {
        return Optional.empty();
    }

    @Override
    public List<Credits> findAll() {
        return null;
    }

    @Override
    public void create(Credits entity) {

    }

    @Override
    public void delete(Credits entity) {

    }

    @Override
    public void update(Credits entity) {

    }
}
